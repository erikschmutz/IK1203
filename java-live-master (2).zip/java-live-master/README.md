# java -live

Live reload single java application
